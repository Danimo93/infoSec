<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p><b>IKKE BRUK DISSE LINKENE DERSOM DU IKKE VET HVA DE  ER TIL!"
Misbrukes de er Øvingen over for alle!</b></p>
<p> <a href="addflower.php">Add flower</a></p>
<p> <a href="addarrangement.php">Add arrangement</a></p>
<hr>
<p><b>Housekeeping</b><p>
<p> <a href="clearusers.php">Clear users</a> (should clear sessions and carts after this operation)</p>
<p> <a href="clearsessions.php">Clear sessions</a></p>
<p> <a href="clearcarts.php">Clear carts</a></p>
<p> <a href="clearguestbook.php">Clear guestbook</a></p>
</body>
</html>
